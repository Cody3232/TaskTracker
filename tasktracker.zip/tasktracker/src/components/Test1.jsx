import {useState} from "react";

const Test1 = () => {
  
    const [x, setX] = useState(0);  
const [name, setName] = useState("Cody");
      // usestate[0] has initialized a state variable "X" to 0 and provided a function to setX() to manipulate the value of x.

    return (
        <>
        <p>The value of x is {x}</p>
        <p>Welcome {name}</p>
        <button onClick = {() => {setX(x + 1); setName("Snow")}}>Increment</button>
        <p>The value of y is {x * 2}</p>
        {document.title = x}
        </>
    )
};

export default Test1
