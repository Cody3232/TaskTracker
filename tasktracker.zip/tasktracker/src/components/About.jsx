import { Link } from "react-router-dom";
const About = () => {
  return (
    <div>
        <h3>Version 1.0.0</h3>
        <Link to ="/">Go Back</Link> 
        {/* This is called Home route */}
    </div>
  )
}

export default About;
