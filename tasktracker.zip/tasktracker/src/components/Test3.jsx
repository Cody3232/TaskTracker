import { useState } from "react";

const Test3 = () => {
    let num = [11, 22, 33, 55];
    let [numbers, setNumbers] = useState(num);

    return (
        <>
            <ul>
                {numbers.map((n, i) => (
                    <div key={i}>
                        <li>{n}</li>
                    </div>
                ))}
            </ul>
            <button onClick={() => {
                setNumbers((previousState) => {
                    return [...previousState, Math.floor(Math.random() * 50)];
                });
            }}>
                Change Array
            </button>
        </>
    );
};

export default Test3;
