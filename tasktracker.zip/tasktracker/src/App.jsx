import Footer from "./components/Footer";
import Header from "./components/Header";
import { useState, useEffect } from "react";
import AnimatedRoutes from "./components/AnimatedRoutes";
import { BrowserRouter as Router, Link } from "react-router-dom";

function App() {
  const [showAddTask, setShowAddTask] = useState(false);
  

  return (
    <Router>
      
    <div className = "container">
      <Header title = "Task tracker" onAdd = {() => setShowAddTask (!showAddTask)} showAdd = {showAddTask}/>
<AnimatedRoutes showAddTask = {showAddTask} />      
          <Link to = "/" className = "link">Home</Link>
          <Link to = "/about" className = "link">About</Link>
          <Link to = "/test1" className = "link">Test1</Link>
          <Link to = "/test2" className = "link">Test2</Link>
          <Link to = "/test3" className = "link">Test3</Link>
      <Footer />
    </div>
    </Router>
  );
}

// && logical and... both sides should be true for a true output... If either side is false, the output is false

// We will set up our own server to test our API calls... 

// This will be  JSON server... It will have all the takss on it and we will fetch the tasks fromt he server and show them here. Also make other API calls lik.... get, post, delete
export default App;
